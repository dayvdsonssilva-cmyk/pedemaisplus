-- =========================================================
-- IMPULSO - Schema do banco (Supabase / Postgres)
-- Rode isso inteiro no SQL Editor do Supabase.
-- Se voce ja tinha rodado uma versao anterior deste schema,
-- pode rodar esse arquivo de novo por cima sem problema
-- (tudo usa "if not exists" / "or replace" / "drop policy if exists").
-- =========================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------
-- Tabela: profiles
-- Dados fisicos e meta de cada usuario. id = auth.users.id
-- ---------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  idade int not null,
  sexo text not null check (sexo in ('masculino','feminino','outro')),
  altura_cm numeric not null,
  peso_inicial_kg numeric not null,
  peso_atual_kg numeric not null,
  peso_meta_kg numeric not null,
  nivel_atividade text not null default 'leve'
    check (nivel_atividade in ('sedentario','leve','moderado','ativo','muito_ativo')),
  ritmo_perda_kg_semana numeric not null default 0.5,
  onboarding_completo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- Tabela: checkins
-- Um registro por dia: peso do dia e calorias consumidas.
-- (o treino em si fica na tabela "treinos" abaixo, separada,
-- pra dar pra registrar mais de um treino no mesmo dia sem
-- um sobrescrever o outro)
-- ---------------------------------------------------------
create table if not exists public.checkins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  data date not null default current_date,
  peso_kg numeric,
  treinou boolean not null default false,
  calorias_consumidas int,
  observacao text,
  created_at timestamptz not null default now(),
  unique (user_id, data)
);

create index if not exists idx_checkins_user_data
  on public.checkins (user_id, data desc);

-- Se a tabela ja existia de uma versao anterior com essas colunas,
-- elas migram sozinhas pra tabela treinos e somem daqui:
alter table public.checkins drop column if exists tipo_exercicio;
alter table public.checkins drop column if exists duracao_min;
alter table public.checkins drop column if exists calorias_gastas_exercicio;

-- ---------------------------------------------------------
-- Tabela: treinos
-- Cada treino registrado vira uma linha propria. Um dia pode
-- ter varios treinos, cada um guardado sem apagar o anterior.
-- ---------------------------------------------------------
create table if not exists public.treinos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  data date not null default current_date,
  hora time not null default current_time,
  tipo_exercicio text not null,
  duracao_min int not null check (duracao_min > 0 and duracao_min <= 240),
  calorias_gastas_exercicio int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_treinos_user_data
  on public.treinos (user_id, data desc, hora desc);

-- ---------------------------------------------------------
-- RLS: cada usuario so ve e mexe nos proprios dados.
-- ---------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.checkins enable row level security;
alter table public.treinos enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "profiles_delete_own" on public.profiles;
create policy "profiles_delete_own" on public.profiles for delete using (auth.uid() = id);

drop policy if exists "checkins_select_own" on public.checkins;
create policy "checkins_select_own" on public.checkins for select using (auth.uid() = user_id);

drop policy if exists "checkins_insert_own" on public.checkins;
create policy "checkins_insert_own" on public.checkins for insert with check (auth.uid() = user_id);

drop policy if exists "checkins_update_own" on public.checkins;
create policy "checkins_update_own" on public.checkins for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "checkins_delete_own" on public.checkins;
create policy "checkins_delete_own" on public.checkins for delete using (auth.uid() = user_id);

drop policy if exists "treinos_select_own" on public.treinos;
create policy "treinos_select_own" on public.treinos for select using (auth.uid() = user_id);

drop policy if exists "treinos_insert_own" on public.treinos;
create policy "treinos_insert_own" on public.treinos for insert with check (auth.uid() = user_id);

drop policy if exists "treinos_update_own" on public.treinos;
create policy "treinos_update_own" on public.treinos for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "treinos_delete_own" on public.treinos;
create policy "treinos_delete_own" on public.treinos for delete using (auth.uid() = user_id);

-- ---------------------------------------------------------
-- Trigger: atualiza updated_at automaticamente no profiles
-- ---------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql security definer set search_path = public;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

-- =========================================================
-- RANKING (gamificacao) - a prova de trapaca
--
-- Regra de pontuacao (mesma logica do front-end, replicada aqui
-- pra o ranking sempre bater com o que o app mostra):
--   30 pontos por DIA diferente treinado (nao por treino avulso -
--     treinar 1x ou 5x no mesmo dia conta igual)
--   10 pontos por dia de sequencia (streak) atual
--   ate 20 pontos/dia de bonus de calorias, travado em 400kcal/dia
--     contadas (depois disso, mais duracao/calorias digitadas nao
--     rende mais pontos)
--
-- Essas funcoes rodam como SECURITY DEFINER, ou seja, tem
-- permissao pra olhar os treinos de QUALQUER usuario mesmo com
-- RLS ativo - mas so devolvem numero de pontos e nome, nunca os
-- dados privados (peso, idade, etc). E assim que se expoe um
-- ranking publico com seguranca: a funcao decide exatamente o
-- que sai, o RLS das tabelas continua intacto pra tudo o mais.
-- =========================================================

create or replace function public.calcular_streak(p_user_id uuid)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  resultado int := 0;
  data_cursor date := current_date;
  existe boolean;
begin
  loop
    select exists(
      select 1 from public.treinos where user_id = p_user_id and data = data_cursor
    ) into existe;
    exit when not existe;
    resultado := resultado + 1;
    data_cursor := data_cursor - 1;
  end loop;
  return resultado;
end;
$$;

create or replace function public.calcular_pontos(p_user_id uuid)
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  dias_treinados int;
  bonus_calorico int;
  streak int;
begin
  select count(distinct data) into dias_treinados
  from public.treinos
  where user_id = p_user_id;

  select coalesce(sum(least(total_dia, 400) / 20), 0)::int into bonus_calorico
  from (
    select data, sum(calorias_gastas_exercicio) as total_dia
    from public.treinos
    where user_id = p_user_id
    group by data
  ) por_dia;

  streak := public.calcular_streak(p_user_id);

  return (dias_treinados * 30) + (streak * 10) + bonus_calorico;
end;
$$;

-- Funcao publica: qualquer usuario logado pode chamar, mas ela so
-- devolve nome (primeiro nome) + pontos de quem completou o
-- onboarding. Nenhum dado sensivel sai daqui.
create or replace function public.obter_ranking()
returns table(user_id uuid, nome text, pontos int, dias_treinados int, streak int)
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
    select
      p.id,
      split_part(p.nome, ' ', 1),
      public.calcular_pontos(p.id),
      (select count(distinct data)::int from public.treinos where user_id = p.id),
      public.calcular_streak(p.id)
    from public.profiles p
    where p.onboarding_completo = true
    order by 3 desc;
end;
$$;

grant execute on function public.obter_ranking() to authenticated;
grant execute on function public.calcular_pontos(uuid) to authenticated;
grant execute on function public.calcular_streak(uuid) to authenticated;

-- ---------------------------------------------------------
-- Fim do schema.
-- ---------------------------------------------------------
